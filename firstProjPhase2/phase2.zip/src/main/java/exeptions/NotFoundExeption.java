package exeptions;

public class NotFoundExeption extends Exception{
    public NotFoundExeption(){
        super("not found !");
    }
}
