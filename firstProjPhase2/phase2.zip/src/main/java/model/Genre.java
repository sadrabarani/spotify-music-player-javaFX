package model;

public enum Genre {
    Rock,
    Pop,
    Jazz,
    HipHop,
    Country,
    TrueCrime,
    Society,
    Interview,
    History;
}
